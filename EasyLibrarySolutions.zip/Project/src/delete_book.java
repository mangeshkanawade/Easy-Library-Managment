public class delete_book
{
	
}